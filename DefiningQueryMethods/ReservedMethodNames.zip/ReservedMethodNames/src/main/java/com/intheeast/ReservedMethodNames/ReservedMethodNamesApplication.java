package com.intheeast.ReservedMethodNames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservedMethodNamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservedMethodNamesApplication.class, args);
	}

}
