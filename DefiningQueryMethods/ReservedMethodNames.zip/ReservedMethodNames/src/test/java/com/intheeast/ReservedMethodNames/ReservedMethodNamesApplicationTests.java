package com.intheeast.ReservedMethodNames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservedMethodNamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
